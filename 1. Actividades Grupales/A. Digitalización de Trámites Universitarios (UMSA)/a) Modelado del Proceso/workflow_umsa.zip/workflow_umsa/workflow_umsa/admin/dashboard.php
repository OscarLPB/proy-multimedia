<?php
require_once __DIR__ . '/../includes/auth.php';
exigirRol('admin');

$totalEstudiantes = count(obtenerEstudiantes());
$totalInscritos = contarEstudiantesInscritos();
$totalNoInscritos = contarEstudiantesNoInscritos();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel administrador</title>
    <link rel="stylesheet" href="<?= asset('assets/css/estilos.css') ?>?v=3">
</head>
<body>

<header class="topbar">
    <div>
        <h1>Panel administrador</h1>
        <p>Bienvenido, <?= h(usuarioActual()['nombre']) ?></p>
    </div>

    <div class="actions">
        
        <a class="btn btn-light" href="../cambiar_password.php">Cambiar contraseña</a>
        <a class="btn btn-light" href="<?= url('logout.php') ?>">Salir</a>
    </div>
</header>

<main class="container">

    <div class="workflow-line">
        <div class="step active">1. Admin</div>
        <div class="step active">2. Sortea horarios</div>
        <div class="step">3. Estudiantes ingresan</div>
        <div class="step">4. Inscripción</div>
    </div>

    <section class="cards">
        <article class="card">
            <h3>Total estudiantes</h3>
            <p class="big"><?= $totalEstudiantes ?></p>
        </article>

        <article class="card">
            <h3>Inscritos</h3>
            <p class="big"><?= $totalInscritos ?></p>
        </article>

        <article class="card">
            <h3>No inscritos</h3>
            <p class="big"><?= $totalNoInscritos ?></p>
        </article>
    </section>

    <section class="panel">
        <h2>Acciones administrativas</h2>

        <div class="actions">
            <a class="btn btn-primary" href="sortear_horarios.php">Sortear horarios</a>
        </div>
    </section>
</main>

<script src="<?= asset('assets/js/theme.js') ?>?v=1"></script>

</body>
</html>