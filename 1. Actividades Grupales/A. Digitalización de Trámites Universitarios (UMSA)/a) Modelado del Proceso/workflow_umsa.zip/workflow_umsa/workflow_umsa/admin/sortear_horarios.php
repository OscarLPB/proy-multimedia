<?php
require_once __DIR__ . '/../includes/auth.php';
exigirRol('admin');

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $duracion = (int)($_POST['duracion'] ?? 2);
    $aleatorio = isset($_POST['aleatorio']);

    $estudiantes = obtenerEstudiantes();

    if ($aleatorio) {
        shuffle($estudiantes);
    }

    $horarios = [];
    $inicioBase = new DateTime();

    foreach ($estudiantes as $index => $estudiante) {
        $inicio = clone $inicioBase;
        $inicio->modify('+' . ($index * $duracion) . ' minutes');

        $fin = clone $inicio;
        $fin->modify('+' . $duracion . ' minutes');

        $horarios[] = [
            'estudiante_id' => $estudiante['id'],
            'tipo' => 'regular',
            'inicio' => $inicio->format('Y-m-d H:i:s'),
            'fin' => $fin->format('Y-m-d H:i:s')
        ];
    }

    guardarHorarios($horarios);

    $mensaje = 'Horarios generados correctamente. El primer estudiante puede inscribirse ahora.';
}

$horarios = obtenerHorarios();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sortear horarios</title>
    <link rel="stylesheet" href="<?= asset('assets/css/estilos.css') ?>?v=3">
</head>
<body>

<header class="topbar">
    <div>
        <h1>Sortear horarios</h1>
        <p>Asignación secuencial de turnos de inscripción</p>
    </div>
    <a class="btn btn-light" href="<?= url('admin/dashboard.php') ?>">Volver</a>
</header>

<main class="container">

    <div class="workflow-line">
        <div class="step done">1. Login admin</div>
        <div class="step active">2. Generar horarios</div>
        <div class="step">3. Esperar turno</div>
        <div class="step">4. Inscripción</div>
    </div>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= h($mensaje) ?></div>
    <?php endif; ?>

    <section class="panel">
        <h2>Generar prueba de turnos</h2>

        <p>
            Para probar rápido, coloca duración de 1 o 2 minutos.
            Así podrás ver cómo un estudiante se inscribe y los demás esperan.
        </p>

        <form method="post" class="form-grid">
            <label>
                Duración por estudiante, en minutos
                <input type="number" name="duracion" value="2" min="1" required>
            </label>

            <label class="checkbox-label">
                <input type="checkbox" name="aleatorio" checked>
                Sortear aleatoriamente
            </label>

            <button class="btn btn-primary" type="submit">
                Generar horarios desde ahora
            </button>
        </form>
    </section>

    <section class="panel">
        <h2>Horarios asignados</h2>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Estudiante</th>
                        <th>Tipo</th>
                        <th>Inicio</th>
                        <th>Fin</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($horarios as $h): ?>
                        <?php $estudiante = buscarUsuarioPorId((int)$h['estudiante_id']); ?>
                        <tr>
                            <td><?= h($estudiante['nombre'] ?? 'Desconocido') ?></td>
                            <td><?= h($h['tipo']) ?></td>
                            <td><?= h($h['inicio']) ?></td>
                            <td><?= h($h['fin']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>

</main>

<script src="<?= asset('assets/js/theme.js') ?>?v=1"></script>

</body>
</html>