<?php
require_once __DIR__ . '/includes/auth.php';
exigirLogin();

$mensaje = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actual = trim($_POST['actual'] ?? '');
    $nueva = trim($_POST['nueva'] ?? '');
    $confirmar = trim($_POST['confirmar'] ?? '');

    if ($nueva === '' || strlen($nueva) < 4) {
        $error = 'La nueva contraseña debe tener al menos 4 caracteres.';
    } elseif ($nueva !== $confirmar) {
        $error = 'La confirmación no coincide.';
    } else {
        $ok = cambiarPasswordUsuario((int)usuarioActual()['id'], $actual, $nueva);

        if ($ok) {
            $mensaje = 'Contraseña actualizada correctamente.';
        } else {
            $error = 'La contraseña actual es incorrecta.';
        }
    }
}

$volver = usuarioActual()['rol'] === 'admin'
    ? 'admin/dashboard.php'
    : 'estudiante/dashboard.php';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar contraseña</title>
    <link rel="stylesheet" href="<?= asset('assets/css/estilos.css') ?>?v=3">
</head>
<body>

<header class="topbar">
    <div>
        <h1>Cambiar contraseña</h1>
        <p><?= h(usuarioActual()['nombre']) ?></p>
    </div>
    <a class="btn btn-light" href="<?= h($volver) ?>">Volver</a>
</header>

<main class="container">
    <section class="panel">
        <?php if ($mensaje): ?>
            <div class="alert alert-success"><?= h($mensaje) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= h($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <label>
                Contraseña actual
                <input type="password" name="actual" required>
            </label>

            <label>
                Nueva contraseña
                <input type="password" name="nueva" required>
            </label>

            <label>
                Confirmar nueva contraseña
                <input type="password" name="confirmar" required>
            </label>

            <button class="btn btn-primary" type="submit">Guardar contraseña</button>
        </form>
    </section>
</main>

<script src="<?= asset('assets/js/theme.js') ?>?v=1"></script>

</body>

</html>