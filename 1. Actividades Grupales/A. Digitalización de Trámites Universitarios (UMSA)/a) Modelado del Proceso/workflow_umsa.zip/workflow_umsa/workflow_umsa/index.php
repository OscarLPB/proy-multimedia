<?php
require_once __DIR__ . '/includes/auth.php';

if (!estaLogueado()) {
    header('Location: login.php');
    exit;
}

if (usuarioActual()['rol'] === 'admin') {
    header('Location: admin/dashboard.php');
    exit;
}

if (usuarioActual()['rol'] === 'estudiante') {
    header('Location: estudiante/dashboard.php');
    exit;
}