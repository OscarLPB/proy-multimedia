<?php
require_once __DIR__ . '/includes/auth.php';

$error = '';

if (!isset($_SESSION['captcha_a'], $_SESSION['captcha_b'])) {
    $_SESSION['captcha_a'] = random_int(1, 9);
    $_SESSION['captcha_b'] = random_int(1, 9);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $captcha = (int)($_POST['captcha'] ?? 0);

    $respuestaCorrecta = $_SESSION['captcha_a'] + $_SESSION['captcha_b'];

    if ($captcha !== $respuestaCorrecta) {
        $error = 'CAPTCHA incorrecto.';
    } else {
        $u = buscarUsuarioPorLogin($usuario, $password);

        if ($u) {
            unset($_SESSION['captcha_a'], $_SESSION['captcha_b']);
            loginUsuario($u);
            header('Location: index.php');
            exit;
        }

        $error = 'Usuario o contraseña incorrectos.';
    }

    $_SESSION['captcha_a'] = random_int(1, 9);
    $_SESSION['captcha_b'] = random_int(1, 9);
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Workflow UMSA</title>
    <link rel="stylesheet" href="<?= asset('assets/css/estilos.css') ?>?v=3">
</head>
<body class="login-body">

<button 
    class="theme-toggle theme-toggle-login" 
    type="button" 
    id="themeToggle"
    title="Cambiar tema"
    aria-label="Cambiar tema"
>
    <span id="themeIcon">🌙</span>
</button>

<div class="login-card">
    <img src="assets/img/logo_umsa.jpg" class="logo-login" alt="Logo UMSA">

    <h1>Workflow UMSA</h1>
    <p>Sistema de inscripción universitaria</p>

    <button class="btn btn-light btn-block" type="button" id="themeToggle">
        Modo oscuro
    </button>

    <div class="workflow-mini">
        <span class="active">Login</span>
        <span>Horario</span>
        <span>Inscripción</span>
        <span>Final</span>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <label>
            Usuario
            <input type="text" name="usuario" required>
        </label>

        <label>
            Contraseña
            <input type="password" name="password" required>
        </label>

        <label>
            CAPTCHA: ¿Cuánto es <?= (int)$_SESSION['captcha_a'] ?> + <?= (int)$_SESSION['captcha_b'] ?>?
            <input type="number" name="captcha" required>
        </label>

        <button class="btn btn-primary" type="submit">Ingresar</button>
    </form>
       
    <div class="info-login">
        <p>Ingrese con sus credenciales asignadas por el sistema.</p>
    </div>
</div>

<script src="<?= asset('assets/js/theme.js') ?>?v=1"></script>

</body>

</html>