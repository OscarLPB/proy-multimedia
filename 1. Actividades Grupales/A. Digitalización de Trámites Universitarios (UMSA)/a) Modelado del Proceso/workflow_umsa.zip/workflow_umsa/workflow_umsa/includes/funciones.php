<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function h(?string $texto): string
{
    return htmlspecialchars((string)$texto, ENT_QUOTES, 'UTF-8');
}

function leerJson(string $archivo): array
{
    if (!file_exists($archivo)) {
        file_put_contents($archivo, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    $contenido = file_get_contents($archivo);
    $datos = json_decode($contenido ?: '[]', true);

    return is_array($datos) ? $datos : [];
}

function guardarJson(string $archivo, array $datos): void
{
    file_put_contents(
        $archivo,
        json_encode($datos, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );
}

function obtenerUsuarios(): array
{
    $datos = leerJson(USUARIOS_JSON);
    return $datos['usuarios'] ?? [];
}

function guardarUsuarios(array $usuarios): void
{
    guardarJson(USUARIOS_JSON, [
        'usuarios' => $usuarios
    ]);
}

function buscarUsuarioPorLogin(string $usuario, string $password): ?array
{
    foreach (obtenerUsuarios() as $u) {
        if ($u['usuario'] === $usuario && $u['password'] === $password) {
            return $u;
        }
    }

    return null;
}

function buscarUsuarioPorId(int $id): ?array
{
    foreach (obtenerUsuarios() as $u) {
        if ((int)$u['id'] === $id) {
            return $u;
        }
    }

    return null;
}

function cambiarPasswordUsuario(int $id, string $passwordActual, string $nuevoPassword): bool
{
    $usuarios = obtenerUsuarios();

    foreach ($usuarios as &$u) {
        if ((int)$u['id'] === $id && $u['password'] === $passwordActual) {
            $u['password'] = $nuevoPassword;
            guardarUsuarios($usuarios);
            return true;
        }
    }

    return false;
}

function obtenerEstudiantes(): array
{
    return array_values(array_filter(obtenerUsuarios(), function ($u) {
        return $u['rol'] === 'estudiante';
    }));
}

function obtenerMaterias(): array
{
    $datos = leerJson(MATERIAS_JSON);
    return $datos['materias'] ?? [];
}

function obtenerHorarios(): array
{
    $datos = leerJson(HORARIOS_JSON);
    return $datos['horarios'] ?? [];
}

function guardarHorarios(array $horarios): void
{
    guardarJson(HORARIOS_JSON, [
        'horarios' => $horarios
    ]);
}

function obtenerHorarioEstudiante(int $estudianteId): ?array
{
    foreach (obtenerHorarios() as $horario) {
        if ((int)$horario['estudiante_id'] === $estudianteId) {
            return $horario;
        }
    }

    return null;
}

function estudianteEnHorarioPermitido(int $estudianteId): bool
{
    $horario = obtenerHorarioEstudiante($estudianteId);

    if (!$horario) {
        return false;
    }

    $ahora = new DateTime();
    $inicio = new DateTime($horario['inicio']);
    $fin = new DateTime($horario['fin']);

    return $ahora >= $inicio && $ahora <= $fin;
}

function estadoHorarioEstudiante(int $estudianteId): string
{
    $horario = obtenerHorarioEstudiante($estudianteId);

    if (!$horario) {
        return 'sin_horario';
    }

    $ahora = new DateTime();
    $inicio = new DateTime($horario['inicio']);
    $fin = new DateTime($horario['fin']);

    if ($ahora < $inicio) {
        return 'esperando';
    }

    if ($ahora >= $inicio && $ahora <= $fin) {
        return 'habilitado';
    }

    return 'vencido';
}

function obtenerInscripciones(): array
{
    $datos = leerJson(INSCRIPCIONES_JSON);
    return $datos['inscripciones'] ?? [];
}

function guardarInscripciones(array $inscripciones): void
{
    guardarJson(INSCRIPCIONES_JSON, [
        'inscripciones' => $inscripciones
    ]);
}

function estudianteYaInscrito(int $estudianteId): bool
{
    foreach (obtenerInscripciones() as $inscripcion) {
        if ((int)$inscripcion['estudiante_id'] === $estudianteId) {
            return true;
        }
    }

    return false;
}

function obtenerInscripcionEstudiante(int $estudianteId): ?array
{
    foreach (obtenerInscripciones() as $inscripcion) {
        if ((int)$inscripcion['estudiante_id'] === $estudianteId) {
            return $inscripcion;
        }
    }

    return null;
}

function contarInscritosMateriaParalelo(int $materiaId, string $paralelo): int
{
    $total = 0;

    foreach (obtenerInscripciones() as $inscripcion) {
        foreach ($inscripcion['materias'] as $materia) {
            if ((int)$materia['materia_id'] === $materiaId && $materia['paralelo'] === $paralelo) {
                $total++;
            }
        }
    }

    return $total;
}

function hayCupo(int $materiaId, string $paralelo): bool
{
    foreach (obtenerMaterias() as $materia) {
        if ((int)$materia['id'] === $materiaId) {
            foreach ($materia['paralelos'] as $p) {
                if ($p['nombre'] === $paralelo) {
                    $inscritos = contarInscritosMateriaParalelo($materiaId, $paralelo);
                    return $inscritos < (int)$p['cupo'];
                }
            }
        }
    }

    return false;
}

function contarEstudiantesInscritos(): int
{
    $ids = [];

    foreach (obtenerInscripciones() as $inscripcion) {
        $ids[] = (int)$inscripcion['estudiante_id'];
    }

    return count(array_unique($ids));
}

function contarEstudiantesNoInscritos(): int
{
    return count(obtenerEstudiantes()) - contarEstudiantesInscritos();
}

function asset(string $ruta): string
{
    return BASE_URL . '/' . ltrim($ruta, '/');
}

function url(string $ruta): string
{
    return BASE_URL . '/' . ltrim($ruta, '/');
}