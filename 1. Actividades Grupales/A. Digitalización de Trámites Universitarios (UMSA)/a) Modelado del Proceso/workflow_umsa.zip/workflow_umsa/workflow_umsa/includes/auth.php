<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/funciones.php';

function loginUsuario(array $usuario): void
{
    $_SESSION['usuario'] = [
        'id' => $usuario['id'],
        'usuario' => $usuario['usuario'],
        'nombre' => $usuario['nombre'],
        'rol' => $usuario['rol']
    ];
}

function usuarioActual(): ?array
{
    return $_SESSION['usuario'] ?? null;
}

function estaLogueado(): bool
{
    return usuarioActual() !== null;
}

function cerrarSesion(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}

function exigirLogin(): void
{
    if (!estaLogueado()) {
        header('Location: ' . url('login.php'));
        exit;
    }
}

function exigirRol(string $rol): void
{
    exigirLogin();

    if (usuarioActual()['rol'] !== $rol) {
        header('Location: ' . url('index.php'));
        exit;
    }
}