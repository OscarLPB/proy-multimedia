<?php
declare(strict_types=1);

date_default_timezone_set('America/La_Paz');

define('APP_NAME', 'Sistema Workflow UMSA');

// Si tu proyecto está en: http://localhost/workflow_umsa/
define('BASE_URL', '/workflow_umsa');

define('BASE_PATH', dirname(__DIR__));
define('DATA_PATH', BASE_PATH . '/data');

define('USUARIOS_JSON', DATA_PATH . '/usuarios.json');
define('MATERIAS_JSON', DATA_PATH . '/materias.json');
define('HORARIOS_JSON', DATA_PATH . '/horarios_inscripcion.json');
define('INSCRIPCIONES_JSON', DATA_PATH . '/inscripciones.json');