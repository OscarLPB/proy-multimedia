<?php
require_once __DIR__ . '/../includes/auth.php';
exigirRol('estudiante');

$usuario = usuarioActual();
$estudianteId = (int)$usuario['id'];

$materias = obtenerMaterias();
$horario = obtenerHorarioEstudiante($estudianteId);

$error = '';
$mensaje = '';

$puedeInscribirse = estudianteEnHorarioPermitido($estudianteId);
$estadoHorario = estadoHorarioEstudiante($estudianteId);
$yaInscrito = estudianteYaInscrito($estudianteId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($yaInscrito) {
        $error = 'Ya realizaste tu inscripción.';
    } elseif (!$puedeInscribirse) {
        $error = 'No estás dentro de tu horario permitido de inscripción.';
    } else {
        $seleccionadas = $_POST['materias'] ?? [];

        if (count($seleccionadas) === 0) {
            $error = 'Debes seleccionar al menos una materia.';
        } elseif (count($seleccionadas) > 6) {
            $error = 'Solo puedes inscribirte como máximo a 6 materias.';
        } else {
            $materiasInscritas = [];
            $materiasRepetidas = [];

            foreach ($seleccionadas as $item) {
                [$materiaId, $paralelo] = explode('|', $item);

                $materiaId = (int)$materiaId;

                if (in_array($materiaId, $materiasRepetidas, true)) {
                    $error = 'No puedes elegir la misma materia en dos paralelos distintos.';
                    break;
                }

                $materiasRepetidas[] = $materiaId;

                if (!hayCupo($materiaId, $paralelo)) {
                    $error = 'No hay cupo disponible en una de las materias seleccionadas.';
                    break;
                }

                foreach ($materias as $materia) {
                    if ((int)$materia['id'] === $materiaId) {
                        $materiasInscritas[] = [
                            'materia_id' => $materiaId,
                            'sigla' => $materia['sigla'],
                            'nombre' => $materia['nombre'],
                            'paralelo' => $paralelo
                        ];
                    }
                }
            }

            if (!$error) {
                $inscripciones = obtenerInscripciones();

                $nuevoId = empty($inscripciones)
                    ? 1
                    : max(array_column($inscripciones, 'id')) + 1;

                $inscripciones[] = [
                    'id' => $nuevoId,
                    'estudiante_id' => $estudianteId,
                    'fecha' => date('Y-m-d H:i:s'),
                    'estado' => 'inscripcion_registrada',
                    'materias' => $materiasInscritas
                ];

                guardarInscripciones($inscripciones);

                $mensaje = 'Inscripción registrada correctamente.';
                $yaInscrito = true;
            }
        }
    }
}

$inscripcionActual = obtenerInscripcionEstudiante($estudianteId);
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscripción de materias</title>
    <link rel="stylesheet" href="<?= asset('assets/css/estilos.css') ?>?v=3">
</head>
<body>

<header class="topbar">
    <div>
        <h1>Inscripción de materias</h1>
        <p>Bienvenido, <?= h($usuario['nombre']) ?></p>
    </div>

    <div class="actions">
        <a class="btn btn-light" href="<?= url('estudiante/dashboard.php') ?>">Volver</a>
        <a class="btn btn-light" href="<?= url('logout.php') ?>">Salir</a>
    </div>
</header>

<main class="container">

    <div class="workflow-line">
        <div class="step done">1. Login</div>
        <div class="step done">2. Horario asignado</div>
        <div class="step <?= $puedeInscribirse && !$yaInscrito ? 'active' : '' ?>">3. Selección de materias</div>
        <div class="step <?= $yaInscrito ? 'done' : '' ?>">4. Inscripción registrada</div>
    </div>

    <section class="panel">
        <h2>Mi horario de inscripción</h2>

        <?php if ($horario): ?>
            <p><strong>Inicio:</strong> <?= h($horario['inicio'] ?? 'No asignado') ?></p>
            <p><strong>Fin:</strong> <?= h($horario['fin'] ?? 'No asignado') ?></p>
            <p><strong>Hora actual del servidor:</strong> <?= date('Y-m-d H:i:s') ?></p>
        <?php else: ?>
            <div class="alert alert-warning">Todavía no tienes horario asignado.</div>
        <?php endif; ?>
    </section>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= h($mensaje) ?></div>
    <?php endif; ?>

    <?php if ($yaInscrito && $inscripcionActual): ?>
        <section class="panel">
            <h2>Inscripción finalizada</h2>

            <div class="alert alert-success">
                Tu inscripción fue registrada correctamente.
            </div>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Sigla</th>
                            <th>Materia</th>
                            <th>Paralelo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inscripcionActual['materias'] as $m): ?>
                            <tr>
                                <td><?= h($m['sigla']) ?></td>
                                <td><?= h($m['nombre']) ?></td>
                                <td><?= h($m['paralelo']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

    <?php elseif (!$puedeInscribirse): ?>
        <section class="panel">
            <h2>Inscripción bloqueada</h2>

            <?php if ($estadoHorario === 'esperando'): ?>
                <div class="alert alert-warning">
                    Todavía no es tu turno. Debes esperar tu horario asignado.
                </div>
            <?php elseif ($estadoHorario === 'vencido'): ?>
                <div class="alert alert-danger">
                    Tu horario ya venció. Debes esperar la habilitación para rezagados.
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    No tienes horario de inscripción asignado.
                </div>
            <?php endif; ?>
        </section>

    <?php else: ?>
        <form method="post" class="panel">
            <h2>Materias disponibles</h2>

            <p class="muted">
                Puedes seleccionar hasta 6 materias. Lo habitual es tomar aproximadamente 5 materias.
            </p>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Elegir</th>
                            <th>Sigla</th>
                            <th>Materia</th>
                            <th>Paralelo</th>
                            <th>Docente</th>
                            <th>Horario</th>
                            <th>Cupo</th>
                            <th>Inscritos</th>
                            <th>Disponibles</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($materias as $materia): ?>
                            <?php foreach ($materia['paralelos'] as $p): ?>
                                <?php
                                    $inscritos = contarInscritosMateriaParalelo((int)$materia['id'], $p['nombre']);
                                    $disponibles = (int)$p['cupo'] - $inscritos;
                                    $hayCupoDisponible = $disponibles > 0;
                                ?>
                                <tr>
                                    <td>
                                        <?php if ($hayCupoDisponible): ?>
                                            <input
                                                type="checkbox"
                                                name="materias[]"
                                                value="<?= (int)$materia['id'] ?>|<?= h($p['nombre']) ?>"
                                            >
                                        <?php else: ?>
                                            <span class="badge-danger-text">Sin cupo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= h($materia['sigla']) ?></td>
                                    <td><?= h($materia['nombre']) ?></td>
                                    <td><?= h($p['nombre']) ?></td>
                                    <td><?= h($p['docente']) ?></td>
                                    <td><?= h($p['horario']) ?></td>
                                    <td><?= (int)$p['cupo'] ?></td>
                                    <td><?= $inscritos ?></td>
                                    <td><?= $disponibles ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <br>

            <button class="btn btn-primary" type="submit">
                Registrar inscripción
            </button>
        </form>
    <?php endif; ?>

</main>

<script src="<?= asset('assets/js/theme.js') ?>?v=1"></script>

</body>
</html>