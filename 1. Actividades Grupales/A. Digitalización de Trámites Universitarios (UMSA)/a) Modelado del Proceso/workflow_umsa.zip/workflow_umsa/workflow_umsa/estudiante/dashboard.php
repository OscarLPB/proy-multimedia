<?php
require_once __DIR__ . '/../includes/auth.php';
exigirRol('estudiante');

$usuario = usuarioActual();
$estudianteId = (int)$usuario['id'];

$horario = obtenerHorarioEstudiante($estudianteId);
$yaInscrito = estudianteYaInscrito($estudianteId);
$estadoHorario = estadoHorarioEstudiante($estudianteId);
$puedeInscribirse = estudianteEnHorarioPermitido($estudianteId);
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel estudiante</title>
    <link rel="stylesheet" href="<?= asset('assets/css/estilos.css') ?>?v=4">
</head>
<body>

<header class="topbar">
    <div>
        <h1>Panel estudiante</h1>
        <p>Bienvenido, <?= h(usuarioActual()['nombre']) ?></p>
    </div>

    <div class="actions">
        
        <a class="btn btn-light" href="<?= url('cambiar_password.php') ?>">Cambiar contraseña</a>
        <a class="btn btn-light" href="<?= url('logout.php') ?>">Salir</a>
    </div>
</header>

<main class="container">

    <section class="panel">
        <h2>Trámites universitarios disponibles</h2>
        <p class="muted">
            Selecciona el trámite que deseas realizar dentro del sistema digital.
        </p>

        <div class="cards">

            <article class="card">
                <h3>Inscripción de materias</h3>

                <?php if ($yaInscrito): ?>
                    <div class="alert alert-success">
                        Ya realizaste tu inscripción.
                    </div>
                <?php elseif ($estadoHorario === 'habilitado'): ?>
                    <div class="alert alert-success">
                        Tu turno está habilitado. Puedes inscribirte ahora.
                    </div>
                <?php elseif ($estadoHorario === 'esperando'): ?>
                    <div class="alert alert-warning">
                        Todavía no es tu turno de inscripción.
                    </div>
                <?php elseif ($estadoHorario === 'vencido'): ?>
                    <div class="alert alert-danger">
                        Tu horario venció. Debes esperar rezagados.
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        Aún no tienes horario asignado.
                    </div>
                <?php endif; ?>

                <?php if ($horario): ?>
                    <p><strong>Inicio:</strong> <?= h($horario['inicio'] ?? '') ?></p>
                    <p><strong>Fin:</strong> <?= h($horario['fin'] ?? '') ?></p>
                <?php endif; ?>

                <a class="btn btn-primary" href="<?= url('estudiante/inscripcion.php') ?>">
                    Ir a inscripción
                </a>
            </article>

            <article class="card">
                <h3>Certificados académicos</h3>

                <p>
                    Consulta directa de certificados disponibles para el estudiante.
                </p>

                <ul>
                    <li>Certificado de notas</li>
                    <li>Certificado de estudiante regular</li>
                </ul>

                <a class="btn btn-primary" href="<?= url('estudiante/certificados.php') ?>">
                    Ver certificados
                </a>
            </article>

        </div>
    </section>

    <section class="panel">
        <h2>Workflow general del estudiante</h2>

        <div class="workflow-line">
            <div class="step done">1. Login</div>
            <div class="step active">2. Panel estudiante</div>
            <div class="step">3. Selección de trámite</div>
            <div class="step">4. Validación</div>
            <div class="step">5. Resultado</div>
        </div>
    </section>

</main>

<script src="<?= asset('assets/js/theme.js') ?>?v=1"></script>

</body>
</html>