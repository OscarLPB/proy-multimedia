<?php
require_once __DIR__ . '/../includes/auth.php';
exigirRol('estudiante');

$usuarioSesion = usuarioActual();
$usuario = buscarUsuarioPorId((int)$usuarioSesion['id']);

$tipo = $_GET['tipo'] ?? 'notas';
$notas = $usuario['notas'] ?? [];

$nombreArchivo = $tipo === 'regular'
    ? 'certificado_estudiante_regular_' . $usuario['codigo'] . '.html'
    : 'certificado_notas_' . $usuario['codigo'] . '.html';

header('Content-Type: text/html; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Certificado académico</title>
<style>
body{font-family:Arial;margin:40px;color:#111827}
.certificado{border:2px solid #111827;padding:30px;max-width:850px;margin:auto}
.encabezado{text-align:center;border-bottom:2px solid #111827;padding-bottom:15px;margin-bottom:25px}
.encabezado h1{margin:0;font-size:24px}
.encabezado h2{margin:8px 0 0;font-size:20px}
table{width:100%;border-collapse:collapse;margin-top:25px}
th,td{border:1px solid #111827;padding:10px;text-align:left}
th{background:#e5e7eb}
.firma{margin-top:60px;text-align:center}
.linea{width:260px;border-top:1px solid #111827;margin:0 auto 8px}
.fecha{margin-top:25px;text-align:right}
</style>
</head>
<body>
<div class="certificado">
<div class="encabezado">
<h1>Universidad Mayor de San Andrés</h1>
<h2><?= $tipo==='regular'?'Certificado de Estudiante Regular':'Certificado de Notas' ?></h2>
</div>

<?php if($tipo==='regular'): ?>
<p>La Universidad Mayor de San Andrés certifica que el/la estudiante <strong><?= h($usuario['nombre']) ?></strong>, con código universitario <strong><?= h($usuario['codigo']) ?></strong>, pertenece a la carrera de <strong><?= h($usuario['carrera']) ?></strong>.</p>
<p>El presente certificado es emitido digitalmente a solicitud del interesado.</p>
<?php else: ?>
<p><strong>Estudiante:</strong> <?= h($usuario['nombre']) ?></p>
<p><strong>Código universitario:</strong> <?= h($usuario['codigo']) ?></p>
<p><strong>Carrera:</strong> <?= h($usuario['carrera']) ?></p>
<table>
<thead><tr><th>Sigla</th><th>Materia</th><th>Nota</th><th>Estado</th></tr></thead>
<tbody>
<?php foreach($notas as $n): ?>
<tr>
<td><?= h($n['sigla']) ?></td>
<td><?= h($n['materia']) ?></td>
<td><?= h((string)$n['nota']) ?></td>
<td><?= ((int)$n['nota']>=51)?'Aprobado':'Reprobado' ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php endif; ?>

<p class="fecha"><strong>Fecha de emisión:</strong> <?= date('Y-m-d H:i:s') ?></p>
<div class="firma"><div class="linea"></div><p>Unidad Académica - UMSA</p></div>
</div>
</body>
</html>