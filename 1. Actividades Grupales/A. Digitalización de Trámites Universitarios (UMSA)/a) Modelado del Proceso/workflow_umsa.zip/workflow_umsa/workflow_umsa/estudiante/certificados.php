<?php
require_once __DIR__ . '/../includes/auth.php';
exigirRol('estudiante');

$usuarioSesion = usuarioActual();
$usuario = buscarUsuarioPorId((int)$usuarioSesion['id']);

$tipo = $_GET['tipo'] ?? 'notas';
$notas = $usuario['notas'] ?? [];
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificados académicos</title>
    <link rel="stylesheet" href="<?= asset('assets/css/estilos.css') ?>?v=4">
</head>
<body>

<header class="topbar">
    <div>
        <h1>Certificados académicos</h1>
        <p><?= h($usuario['nombre']) ?></p>
    </div>

    <div class="actions">
        <a class="btn btn-light" href="<?= url('estudiante/dashboard.php') ?>">Volver</a>
        <a class="btn btn-light" href="<?= url('logout.php') ?>">Salir</a>
    </div>
</header>

<main class="container">

    <section class="panel">
        <h2>Workflow del trámite: emisión de certificado</h2>

        <div class="workflow-line">
            <div class="step done">1. Login</div>
            <div class="step done">2. Solicitud</div>
            <div class="step done">3. Validación de datos</div>
            <div class="step active">4. Generación</div>
            <div class="step">5. Impresión</div>
        </div>
    </section>

    <section class="panel">
        <h2>Seleccionar certificado</h2>

        <div class="actions">
            <a class="btn <?= $tipo === 'notas' ? 'btn-primary' : '' ?>" href="?tipo=notas">
                Certificado de notas
            </a>

            <a class="btn <?= $tipo === 'regular' ? 'btn-primary' : '' ?>" href="?tipo=regular">
                Certificado de estudiante regular
            </a>
        </div>
    </section>

    <?php if ($tipo === 'regular'): ?>

        <section class="panel certificado">
            <h2>Certificado de estudiante regular</h2>

            <p>
                La Universidad Mayor de San Andrés certifica que
                <strong><?= h($usuario['nombre']) ?></strong>,
                con código universitario
                <strong><?= h($usuario['codigo']) ?></strong>,
                pertenece a la carrera de
                <strong><?= h($usuario['carrera']) ?></strong>.
            </p>

            <p>
                El presente certificado es emitido de forma digital
                a solicitud del interesado.
            </p>

            <p><strong>Fecha de emisión:</strong> <?= date('Y-m-d') ?></p>

            <a 
                class="btn btn-primary" 
                href="<?= url('estudiante/descargar_certificado.php?tipo=' . $tipo) ?>"
            >
                Imprimir certificado
            </a>

        </section>

    <?php else: ?>

        <section class="panel certificado">
            <h2>Certificado de notas</h2>

            <p>
                Estudiante:
                <strong><?= h($usuario['nombre']) ?></strong>
            </p>

            <p>
                Código universitario:
                <strong><?= h($usuario['codigo']) ?></strong>
            </p>

            <p>
                Carrera:
                <strong><?= h($usuario['carrera']) ?></strong>
            </p>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Sigla</th>
                            <th>Materia</th>
                            <th>Nota</th>
                            <th>Estado</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (empty($notas)): ?>
                            <tr>
                                <td colspan="4">No existen notas registradas.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($notas as $n): ?>
                                <tr>
                                    <td><?= h($n['sigla']) ?></td>
                                    <td><?= h($n['materia']) ?></td>
                                    <td><?= h((string)$n['nota']) ?></td>
                                    <td>
                                        <?= ((int)$n['nota'] >= 51) ? 'Aprobado' : 'Reprobado' ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <br>

            <a 
                class="btn btn-primary" 
                href="<?= url('estudiante/descargar_certificado.php?tipo=notas') ?>"
            >
                Descargar certificado de notas
            </a>
        </section>

    <?php endif; ?>

</main>

<script src="<?= asset('assets/js/theme.js') ?>?v=1"></script>

</body>
</html>