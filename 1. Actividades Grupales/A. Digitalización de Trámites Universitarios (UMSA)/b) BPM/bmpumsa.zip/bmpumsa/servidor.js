import express from 'express';
import fs from 'fs';
import path from 'path';

const app = express();
const PUERTO = 5000;

app.use(express.json());
app.use(express.static('public'));

const CARPETA_TRAMITES = './tramites';

if (!fs.existsSync(CARPETA_TRAMITES)) {
    fs.mkdirSync(CARPETA_TRAMITES, { recursive: true });
}

const FLUJOS_TRAMITE = {
    'Solicitud de Beca Socioeconómica': {
        prefijo: 'SB',
        categoria: 'beca',
        estadoInicial: 'ENTREVISTA_SOCIAL',
        bpmFlujo: [
            { paso: 'Postulación enviada', estado: 'COMPLETADO', responsable: 'Estudiante', icono: '📝' },
            { paso: 'Entrevista y visita domiciliaria', estado: 'EN_PROGRESO', responsable: 'Trabajo Social UMSA', icono: '🏠' },
            { paso: 'Evaluación de mérito académico', estado: 'PENDIENTE', responsable: 'Director de Carrera', icono: '📊' },
            { paso: 'Dictamen de Comisión de Becas', estado: 'PENDIENTE', responsable: 'Comisión de Becas', icono: '⚖️' },
            { paso: 'Resolución y asignación de monto', estado: 'PENDIENTE', responsable: 'Dirección Financiera', icono: '💰' }
        ],
        validar: (datos) => {
            if (!datos.carrera || !datos.promedio || !datos.ingresoFamiliar || !datos.tipoBeca) {
                return 'Para la beca debes indicar carrera, promedio, ingreso familiar y tipo de beca.';
            }
            const promedio = Number(datos.promedio);
            if (Number.isNaN(promedio) || promedio < 0 || promedio > 100) {
                return 'El promedio debe ser un número entre 0 y 100.';
            }
            return null;
        },
        datosEspecificos: (datos) => ({
            carrera: datos.carrera,
            promedio: Number(datos.promedio),
            ingresoFamiliar: Number(datos.ingresoFamiliar),
            tipoBeca: datos.tipoBeca,
            motivo: datos.motivo || ''
        })
    },
    'Solicitud de Conclusión de Estudios': {
        prefijo: 'CE',
        categoria: 'graduacion',
        estadoInicial: 'REVISION_KARDEX',
        bpmFlujo: [
            { paso: 'Solicitud de graduación registrada', estado: 'COMPLETADO', responsable: 'Estudiante', icono: '🎓' },
            { paso: 'Revisión de plan de estudios y créditos', estado: 'EN_PROGRESO', responsable: 'Kardex', icono: '📋' },
            { paso: 'Control de deudas biblioteca', estado: 'PENDIENTE', responsable: 'Biblioteca', icono: '📚' },
            { paso: 'Verificación de equipos de laboratorio', estado: 'PENDIENTE', responsable: 'Laboratorios', icono: '🔬' },
            { paso: 'Emisión de certificado de conclusión', estado: 'PENDIENTE', responsable: 'Consejo de Facultad', icono: '📜' }
        ],
        validar: (datos) => {
            if (!datos.carrera || !datos.semestreActual) {
                return 'Para conclusión de estudios debes indicar carrera y semestre actual.';
            }
            return null;
        },
        datosEspecificos: (datos) => ({
            carrera: datos.carrera,
            semestreActual: datos.semestreActual,
            fechaEstimadaGraduacion: datos.fechaEstimadaGraduacion || ''
        })
    }
};

function rutaTramite(ru) {
    return path.join(CARPETA_TRAMITES, `${ru}.json`);
}

function leerTramite(ru) {
    const ruta = rutaTramite(ru);
    if (!fs.existsSync(ruta)) return null;
    return JSON.parse(fs.readFileSync(ruta, 'utf-8'));
}

function guardarTramite(ru, tramite) {
    fs.writeFileSync(rutaTramite(ru), JSON.stringify(tramite, null, 2));
}

function clonarFlujo(tipoTramite) {
    const config = FLUJOS_TRAMITE[tipoTramite];
    return config.bpmFlujo.map(paso => ({ ...paso }));
}

function pasoEnProgreso(tramite) {
    return tramite.bpm_flujo.find(p => p.estado === 'EN_PROGRESO') || null;
}

function crearTramite({ ru, nombre, ci, tipoTramite, datosExtra = {} }) {
    const config = FLUJOS_TRAMITE[tipoTramite];
    return {
        id_tramite: `${config.prefijo}-${Date.now().toString().slice(-4)}`,
        tipoTramite,
        categoria: config.categoria,
        fecha_creacion: new Date().toLocaleDateString(),
        estado_actual: config.estadoInicial,
        datos_estudiante: { ru, nombre, ci },
        datos_especificos: config.datosEspecificos(datosExtra),
        bpm_flujo: clonarFlujo(tipoTramite)
    };
}

// ---------------------------------------------------------
// 1. REGISTRAR
// ---------------------------------------------------------
app.post('/api/tramites', (req, res) => {
    const { ru, nombre, ci, tipoTramite, sobrescribir, ...datosExtra } = req.body;

    if (!ru || !nombre || !tipoTramite) {
        return res.status(400).json({ error: 'Faltan datos obligatorios.' });
    }

    const configTramite = FLUJOS_TRAMITE[tipoTramite];
    if (!configTramite) {
        return res.status(400).json({ error: 'Tipo de trámite no válido.' });
    }

    const errorValidacion = configTramite.validar(datosExtra);
    if (errorValidacion) {
        return res.status(400).json({ error: errorValidacion });
    }

    const existe = fs.existsSync(rutaTramite(ru));
    if (existe && !sobrescribir) {
        const anterior = leerTramite(ru);
        return res.status(409).json({
            error: `Ya existe un trámite para el RU ${ru} (${anterior.tipoTramite}). Confirma para reemplazarlo.`
        });
    }

    const nuevoTramite = crearTramite({ ru, nombre, ci, tipoTramite, datosExtra });

    try {
        guardarTramite(ru, nuevoTramite);
        res.status(201).json({
            mensaje: existe ? 'Trámite reemplazado con éxito.' : 'Trámite registrado con éxito.',
            tramite: nuevoTramite
        });
    } catch {
        res.status(500).json({ error: 'No se pudo guardar el archivo del trámite.' });
    }
});

// ---------------------------------------------------------
// 2. LISTAR todos los trámites (consulta JSON)
// ---------------------------------------------------------
app.get('/api/tramites', (_req, res) => {
    try {
        const archivos = fs.readdirSync(CARPETA_TRAMITES).filter(f => f.endsWith('.json'));
        const tramites = archivos.map(archivo => {
            const tramite = JSON.parse(fs.readFileSync(path.join(CARPETA_TRAMITES, archivo), 'utf-8'));
            const paso = pasoEnProgreso(tramite);
            return {
                ru: tramite.datos_estudiante.ru,
                nombre: tramite.datos_estudiante.nombre,
                tipoTramite: tramite.tipoTramite,
                categoria: tramite.categoria || 'desconocido',
                estado_actual: tramite.estado_actual,
                paso_actual: paso ? paso.paso : 'Finalizado',
                responsable: paso ? paso.responsable : '-'
            };
        });
        res.json(tramites);
    } catch {
        res.status(500).json({ error: 'Error al listar los trámites.' });
    }
});

// ---------------------------------------------------------
// 3. CONSULTAR por RU
// ---------------------------------------------------------
app.get('/api/tramites/:ru', (req, res) => {
    const { ru } = req.params;

    try {
        const tramite = leerTramite(ru);
        if (!tramite) {
            return res.status(404).json({ error: 'No se encontró ningún trámite activo para este RU.' });
        }
        res.json({
            ...tramite,
            paso_actual: pasoEnProgreso(tramite)
        });
    } catch {
        res.status(500).json({ error: 'Error al leer el archivo del trámite.' });
    }
});

// ---------------------------------------------------------
// 4. AVANZAR paso BPM
// ---------------------------------------------------------
app.put('/api/tramites/:ru/avanzar', (req, res) => {
    const { ru } = req.params;

    try {
        const tramite = leerTramite(ru);
        if (!tramite) {
            return res.status(404).json({ error: 'El trámite no existe.' });
        }

        const indexActual = tramite.bpm_flujo.findIndex(p => p.estado === 'EN_PROGRESO');
        if (indexActual === -1) {
            return res.status(400).json({ error: 'El trámite ya está finalizado. Usa "Reiniciar" para volver a simularlo.' });
        }

        const pasoCompletado = tramite.bpm_flujo[indexActual].paso;
        tramite.bpm_flujo[indexActual].estado = 'COMPLETADO';

        if (indexActual + 1 < tramite.bpm_flujo.length) {
            tramite.bpm_flujo[indexActual + 1].estado = 'EN_PROGRESO';
            tramite.estado_actual = `PROCESO_${tramite.bpm_flujo[indexActual + 1].responsable.toUpperCase().replace(/\s+/g, '_')}`;
        } else {
            tramite.estado_actual = 'FINALIZADO';
        }

        guardarTramite(ru, tramite);
        res.json({
            mensaje: `Paso "${pasoCompletado}" aprobado correctamente.`,
            tramite,
            paso_actual: pasoEnProgreso(tramite)
        });
    } catch {
        res.status(500).json({ error: 'Error al actualizar el flujo del trámite.' });
    }
});

// ---------------------------------------------------------
// 5. REINICIAR trámite (vuelve al flujo inicial del mismo tipo)
// ---------------------------------------------------------
app.put('/api/tramites/:ru/reiniciar', (req, res) => {
    const { ru } = req.params;

    try {
        const tramite = leerTramite(ru);
        if (!tramite) {
            return res.status(404).json({ error: 'El trámite no existe.' });
        }

        if (!FLUJOS_TRAMITE[tramite.tipoTramite]) {
            return res.status(400).json({
                error: `El trámite "${tramite.tipoTramite}" es antiguo. Registra uno nuevo desde el formulario.`
            });
        }

        const config = FLUJOS_TRAMITE[tramite.tipoTramite];
        tramite.estado_actual = config.estadoInicial;
        tramite.bpm_flujo = clonarFlujo(tramite.tipoTramite);
        tramite.fecha_reinicio = new Date().toLocaleDateString();

        guardarTramite(ru, tramite);
        res.json({
            mensaje: 'Trámite reiniciado. El flujo BPM volvió al paso inicial.',
            tramite,
            paso_actual: pasoEnProgreso(tramite)
        });
    } catch {
        res.status(500).json({ error: 'Error al reiniciar el trámite.' });
    }
});

app.listen(PUERTO, () => {
    console.log(`====================================================`);
    console.log(`Sistema BPM-UMSA corriendo en http://localhost:${PUERTO}`);
    console.log(`Usando la carpeta de archivos: ${CARPETA_TRAMITES}`);
    console.log(`====================================================`);
});
