﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DetectorQGIS
{
    public partial class Form1 : Form
    {
        string conexion = "Server=localhost;Database=DetectorQGIS;Integrated Security=True;";

        Bitmap imagenOriginal;
        int pixelR, pixelG, pixelB;

        // Colores fijos por zona para el mapa segmentado
        Dictionary<string, Color> coloresZona = new Dictionary<string, Color>()
        {
            { "agua",       Color.FromArgb(0,   120, 255) },
            { "vegetacion", Color.FromArgb(0,   180, 0)   },
            { "tierra",     Color.FromArgb(139, 90,  43)  },
            { "urbano",     Color.FromArgb(200, 200, 200) },
            { "nieve",      Color.FromArgb(240, 240, 255) }
        };

        public Form1()
        {
            InitializeComponent();
            CargarZonasDesdeBD();
        }

        private void Form1_Load(object sender, EventArgs e) { }

        // ── Cargar zonas existentes en BD al ComboBox ──────────────
        private void CargarZonasDesdeBD()
        {
            comboZona.Items.Clear();
            try
            {
                using (SqlConnection con = new SqlConnection(conexion))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(
                        "SELECT DISTINCT zona FROM Muestras", con);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                        comboZona.Items.Add(reader["zona"].ToString());
                }
            }
            catch { }

            // Zonas por defecto si la BD está vacía
            foreach (string z in new string[] { "agua", "vegetacion", "tierra", "urbano", "nieve" })
                if (!comboZona.Items.Contains(z))
                    comboZona.Items.Add(z);

            if (comboZona.Items.Count > 0)
                comboZona.SelectedIndex = 0;
        }

        // ── Agregar zona personalizada ─────────────────────────────
        private void btnAgregarZona_Click(object sender, EventArgs e)
        {
            string nueva = Microsoft.VisualBasic.Interaction.InputBox(
                "Nombre de la nueva zona:", "Nueva zona", "");

            if (string.IsNullOrWhiteSpace(nueva)) return;

            nueva = nueva.ToLower().Trim();
            if (!comboZona.Items.Contains(nueva))
            {
                comboZona.Items.Add(nueva);
                // Asignar color aleatorio a la nueva zona
                Random rnd = new Random();
                coloresZona[nueva] = Color.FromArgb(
                    rnd.Next(50, 230), rnd.Next(50, 230), rnd.Next(50, 230));
            }
            comboZona.SelectedItem = nueva;
        }

        // ── Cargar imagen ──────────────────────────────────────────
        private void btnCargar_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Imágenes|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imagenOriginal = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = imagenOriginal;
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                lblResultado.Text = "Imagen cargada: " +
                    imagenOriginal.Width + "x" + imagenOriginal.Height;
            }
        }

        // ── Capturar pixel al hacer clic ───────────────────────────

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (imagenOriginal == null) return;

            MouseEventArgs me = (MouseEventArgs)e;

            float scaleX = (float)imagenOriginal.Width / pictureBox1.Width;
            float scaleY = (float)imagenOriginal.Height / pictureBox1.Height;

            int imgX = Math.Max(0, Math.Min((int)(me.X * scaleX), imagenOriginal.Width - 1));
            int imgY = Math.Max(0, Math.Min((int)(me.Y * scaleY), imagenOriginal.Height - 1));

            Color color = imagenOriginal.GetPixel(imgX, imgY);
            pixelR = color.R;
            pixelG = color.G;
            pixelB = color.B;

            lblResultado.Text = "Pixel → R:" + pixelR + " G:" + pixelG + " B:" + pixelB;
        }

        // ── Guardar muestra en BD ──────────────────────────────────
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (comboZona.SelectedItem == null) return;
            string zona = comboZona.SelectedItem.ToString();

            using (SqlConnection con = new SqlConnection(conexion))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Muestras (zona, r, g, b) VALUES (@zona, @r, @g, @b)", con);
                cmd.Parameters.AddWithValue("@zona", zona);
                cmd.Parameters.AddWithValue("@r", pixelR);
                cmd.Parameters.AddWithValue("@g", pixelG);
                cmd.Parameters.AddWithValue("@b", pixelB);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Muestra guardada: " + zona +
                " → R:" + pixelR + " G:" + pixelG + " B:" + pixelB);
        }

        // ── Detectar zonas pixel a pixel (estilo QGIS) ────────────
        private void btnDetectar_Click(object sender, EventArgs e)
        {
            if (imagenOriginal == null)
            {
                MessageBox.Show("Primero carga una imagen.");
                return;
            }

            // Calcular media RGB por zona desde la BD
            Dictionary<string, int[]> medias = new Dictionary<string, int[]>();

            using (SqlConnection con = new SqlConnection(conexion))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(
                    "SELECT zona, AVG(r) as mr, AVG(g) as mg, AVG(b) as mb " +
                    "FROM Muestras GROUP BY zona", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string zona = reader["zona"].ToString();
                    medias[zona] = new int[]
                    {
                        Convert.ToInt32(reader["mr"]),
                        Convert.ToInt32(reader["mg"]),
                        Convert.ToInt32(reader["mb"])
                    };
                }
            }

            if (medias.Count == 0)
            {
                MessageBox.Show("No hay muestras en la BD. Guarda muestras primero.");
                return;
            }

            // Segmentar imagen píxel a píxel
            Bitmap resultado = new Bitmap(imagenOriginal.Width, imagenOriginal.Height);

            for (int y = 0; y < imagenOriginal.Height; y++)
            {
                for (int x = 0; x < imagenOriginal.Width; x++)
                {
                    Color c = imagenOriginal.GetPixel(x, y);

                    string zonaCercana = null;
                    int menorDist = int.MaxValue;

                    foreach (var kvp in medias)
                    {
                        int dist = (int)Math.Sqrt(
                            Math.Pow(c.R - kvp.Value[0], 2) +
                            Math.Pow(c.G - kvp.Value[1], 2) +
                            Math.Pow(c.B - kvp.Value[2], 2));

                        if (dist < menorDist)
                        {
                            menorDist = dist;
                            zonaCercana = kvp.Key;
                        }
                    }

                    // Asignar color de zona al píxel
                    Color colorPixel;
                    if (coloresZona.ContainsKey(zonaCercana))
                        colorPixel = coloresZona[zonaCercana];
                    else
                    {
                        int gris = (int)(c.R * 0.299 + c.G * 0.587 + c.B * 0.114);
                        colorPixel = Color.FromArgb(gris, gris, gris);
                    }

                    resultado.SetPixel(x, y, colorPixel);
                }
            }

            pictureBox2.Image = resultado;
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            lblResultado.Text = "Segmentación completada — " + medias.Count + " zonas detectadas.";
        }


        
    }
}
