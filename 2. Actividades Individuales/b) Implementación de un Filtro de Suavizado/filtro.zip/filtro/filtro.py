import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk

class FiltroApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Filtros de Imagen")

        self.img_filtrada = None
        self.img_original = None

        # Frame para imágenes
        frame_imgs = tk.Frame(root)
        frame_imgs.pack(side=tk.TOP, padx=10, pady=10)

        self.label_original = tk.Label(frame_imgs, text="Original")
        self.label_original.grid(row=0, column=0, padx=10)

        self.label_filtrada = tk.Label(frame_imgs, text="Filtrada")
        self.label_filtrada.grid(row=0, column=1, padx=10)


        # Frame para botones
        frame_botones = tk.Frame(root)
        frame_botones.pack(side=tk.TOP, fill=tk.X, pady=5)

        tk.Button(frame_botones, text="Cargar Imagen", command=self.cargar_imagen).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_botones, text="Suavizado 3x3", command=self.aplicar_suavizado).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_botones, text="Rojo", command=lambda: self.aplicar_color('R')).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_botones, text="Verde", command=lambda: self.aplicar_color('G')).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_botones, text="Azul", command=lambda: self.aplicar_color('B')).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_botones, text="Blanco y Negro", command=self.aplicar_grises).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_botones, text="Invertido", command=self.aplicar_invertido).pack(side=tk.LEFT, padx=5)
        tk.Button(frame_botones, text="Restaurar", command=self.restaurar).pack(side=tk.LEFT, padx=5)

    def cargar_imagen(self):
        ruta = filedialog.askopenfilename(filetypes=[("Imagenes", "*.jpg *.jpeg *.png *.bmp")])
        if not ruta:
            return
        self.img_original = cv2.imread(ruta)
        self.img_filtrada = self.img_original.copy()
        self.mostrar_imagenes()

    def mostrar_imagenes(self):
        self.mostrar_en_label(self.img_original, self.label_original)
        self.mostrar_en_label(self.img_filtrada, self.label_filtrada)

    def mostrar_en_label(self, img_cv, label):
        img_rgb = cv2.cvtColor(img_cv, cv2.COLOR_BGR2RGB)

        # Redimensionar para que no sea enorme
        h, w = img_rgb.shape[:2]
        max_dim = 400
        escala = max_dim / max(h, w)
        nuevo_w, nuevo_h = int(w * escala), int(h * escala)
        img_rgb = cv2.resize(img_rgb, (nuevo_w, nuevo_h))

        img_pil = Image.fromarray(img_rgb)
        img_tk = ImageTk.PhotoImage(img_pil)

        label.configure(image=img_tk)
        label.image = img_tk  # Mantener referencia

    # ---------- FILTROS ----------

    def aplicar_suavizado(self):
        if self.img_original is None:
            return
        #kernel = np.ones((3, 3), np.float32) / 9
        kernel = np.ones((9, 9), np.float32) / 81
        self.img_filtrada = cv2.filter2D(self.img_original, -1, kernel)
        #self.img_filtrada = cv2.GaussianBlur(self.img_original, (15, 15), 0)
        self.mostrar_imagenes()

    def aplicar_color(self, canal):
        if self.img_original is None:
            return
        img = self.img_original.copy()
        b, g, r = cv2.split(img)

        if canal == 'R':
            g[:] = 0
            b[:] = 0
        elif canal == 'G':
            r[:] = 0
            b[:] = 0
        elif canal == 'B':
            r[:] = 0
            g[:] = 0

        self.img_filtrada = cv2.merge([b, g, r])
        self.mostrar_imagenes()

    def aplicar_grises(self):
        if self.img_original is None:
            return
        gris = cv2.cvtColor(self.img_original, cv2.COLOR_BGR2GRAY)
        self.img_filtrada = cv2.cvtColor(gris, cv2.COLOR_GRAY2BGR)
        self.mostrar_imagenes()

    def aplicar_invertido(self):
        if self.img_original is None:
            return
        self.img_filtrada = cv2.bitwise_not(self.img_original)
        self.mostrar_imagenes()

    def restaurar(self):
        if self.img_original is None:
            return
        self.img_filtrada = self.img_original.copy()
        self.mostrar_imagenes()


if __name__ == "__main__":
    root = tk.Tk()
    app = FiltroApp(root)
    root.mainloop()